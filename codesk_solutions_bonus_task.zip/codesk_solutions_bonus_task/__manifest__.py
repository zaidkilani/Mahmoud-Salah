# -*- coding: utf-8 -*-
{
    'name': "Codesksolutions Bonus Task",
    'summary': """
    """,
    'description': """
    """,
    'author': "Mahmoud Salah Abdelmagied",
    'website': "",
    'contributors': [
        'Mahmoud Salah Abdelmagied <mahmoud.salah.abdelmagied@gmail.com>',
    ],
    'version': '0.1',
    'depends': ['base', 'product', 'account', 'stock'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/product_template.xml',
        'views/product_category.xml',
        'views/account_move.xml',
        'views/stock_picking.xml',
    ],
    "pre_init_hook": None,
    "post_init_hook": None,
}
