# -*- coding: utf-8 -*-

##############################################################################
#    Maintainer: Eng.Mahmoud Salah (<mahmoud.salah.abdelmagied@gmail.com>)
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date


class ProductCategory(models.Model):
    _inherit = 'product.category'

    # region Fields

    has_bonus_rules = fields.Boolean('Has Bonus Rules', default=False)

    # endregion

