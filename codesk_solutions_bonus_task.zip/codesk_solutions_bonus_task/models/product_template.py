# -*- coding: utf-8 -*-

##############################################################################
#    Maintainer: Eng.Mahmoud Salah (<mahmoud.salah.abdelmagied@gmail.com>)
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    # region Fields

    is_has_bonus = fields.Boolean('Has Bonus', default=False)
    ordered_quantity = fields.Float(string='Ordered Quantity')
    bonus_quantity = fields.Float(string='Bonus Quantity')

    # endregion

