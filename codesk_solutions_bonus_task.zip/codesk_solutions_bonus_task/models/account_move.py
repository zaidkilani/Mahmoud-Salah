# -*- coding: utf-8 -*-

##############################################################################
#    Maintainer: Eng.Mahmoud Salah (<mahmoud.salah.abdelmagied@gmail.com>)
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date


class AccountMove(models.Model):
    _inherit = 'account.move'

    # region Fields

    bonus_line = fields.Boolean(string='Bonus Line', default=False)

    # endregion

    # region Crud Methods

    def write(self, vals):
        res = super(AccountMove, self).write(vals)
        for move in self:
            line_ids = move.invoice_line_ids.filtered(lambda x: x.bonus_quantity > 0)
            for line in line_ids:
                if not move.bonus_line:
                    move.write({'bonus_line': True,
                                'invoice_line_ids': [(0, 0, {
                                    'move_id': move.id,
                                    'product_id': line.product_id.id,
                                    'name': line.name,
                                    'account_id': line.account_id.id,
                                    'quantity': line.bonus_quantity,
                                    'price_unit': 0.0,
                                    'tax_ids': False,
                                    'price_subtotal': 0.0,
                                })]})
            if move.bonus_line:
                return True
            else:
                return res
    
    # endregion


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    # region Fields

    bonus_quantity = fields.Float(string='Bonus Quantity')

    # endregion

    # region Onchange Methods

    # Method To Get Quantity And Bonus Quantity From Product Automatically
    @api.onchange('product_id')
    def _onchange_product_id(self):
        for line in self:
            if line.product_id:
                line.quantity = line.product_id.ordered_quantity
                line.bonus_quantity = line.product_id.bonus_quantity

    # endregion
