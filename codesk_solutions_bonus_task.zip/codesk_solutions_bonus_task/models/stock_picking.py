# -*- coding: utf-8 -*-

##############################################################################
#    Maintainer: Eng.Mahmoud Salah (<mahmoud.salah.abdelmagied@gmail.com>)
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    # region Fields

    bonus_line = fields.Boolean(string='Bonus Line', default=False)

    # endregion

    # region Crud Methods

    def write(self, vals):
        res = super(StockPicking, self).write(vals)
        for stock in self:
            line_ids = stock.move_ids_without_package.filtered(lambda x: x.bonus_quantity > 0)
            for line in line_ids:
                if not stock.bonus_line:
                    stock.write({'bonus_line': True,
                                'move_ids_without_package': [(0, 0, {
                                    'name': line.name if line.name else "",
                                    'picking_id': stock.id,
                                    'product_id': line.product_id.id,
                                    'product_uom': line.product_uom.id if line.product_uom.id else False,
                                    'location_id': stock.location_id.id if stock.location_id.id else False,
                                    'location_dest_id': stock.location_dest_id.id if stock.location_dest_id.id else False,
                                    'product_uom_qty': line.bonus_quantity,
                                })]})
            if stock.bonus_line:
                return True
            else:
                return res
    
    # endregion


class StockMove(models.Model):
    _inherit = 'stock.move'

    # region Fields

    bonus_quantity = fields.Float(string='Bonus Quantity')

    # endregion

    # region Onchange Methods

    # Method To Get Demand Quantity And Bonus Quantity From Product Automatically
    @api.onchange('product_id')
    def _onchange_product_id(self):
        for line in self:
            if line.product_id:
                line.product_uom_qty = line.product_id.ordered_quantity
                line.name = line.product_id.name
                line.product_uom = line.product_id.uom_id.id
                line.bonus_quantity = line.product_id.bonus_quantity

    # endregion
