# -*- coding: utf-8 -*-

##############################################################################
#    Maintainer: Eng.Mahmoud Salah (<mahmoud.salah.abdelmagied@gmail.com>)
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
##############################################################################

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, date


class ResCurrencyRate(models.Model):
    _inherit = 'res.currency.rate'

    # region Fields

    secondary = fields.Boolean(string='Secondary', default=False)
    base_sale_price = fields.Monetary(string='Base Sale Price')
    base_buy_price = fields.Monetary(string='Base Buy Price')
    secondary_sale_price = fields.Monetary(string='Secondary Sale Price')
    secondary_buy_price = fields.Monetary(string='Secondary Buy Price')
    tolerance = fields.Integer(string='Tolerance')
    count = fields.Boolean(default=False)

    # endregion

    # region Compute Methods

    # Method To Count Tolerance
    @api.constrains('name', 'company_rate', 'inverse_company_rate', 'secondary', 'base_sale_price', 'base_buy_price', 'secondary_sale_price', 'secondary_buy_price')
    def tolerance_count(self):
        for rate in self:
            if rate.name or rate.company_rate or rate.inverse_company_rate or rate.secondary or rate.base_sale_price or rate.base_buy_price or rate.secondary_sale_price or rate.secondary_buy_price:
                rate.tolerance += 1

    # endregion
