# -*- coding: utf-8 -*-
{
    'name': "Codesksolutions Res Currency Task",
    'summary': """
    """,
    'description': """
    """,
    'author': "Mahmoud Salah Abdelmagied",
    'website': "",
    'contributors': [
        'Mahmoud Salah Abdelmagied <mahmoud.salah.abdelmagied@gmail.com>',
    ],
    'version': '0.1',
    'depends': ['base'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/res_currency.xml',
    ],
    "pre_init_hook": None,
    "post_init_hook": None,
}
